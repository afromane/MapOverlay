package classe;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.util.List;

public class MapOverlayDB {
	
	 private Connection connection;

	    public MapOverlayDB() {
	        try {
	            // Établir la connexion à la base de données
	            connection = DriverManager.getConnection("jdbc:sqlite:mapOverlay.db");
	            createTable(); // Créer la table si elle n'existe pas déjà
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    private void createTable() throws SQLException {
	     String mapTable = "CREATE TABLE IF NOT EXISTS maps (id INTEGER PRIMARY KEY, name VARCHAR(30))";
		       
	        String segmentsTable = "CREATE TABLE IF NOT EXISTS segments ("
	        							+ "id INTEGER PRIMARY KEY,"
	        							+ " x1 REAL,"
	        							+ " y1 REAL,"
	        							+ " x2 REAL,"
	        							+ " y2 REAL,"
	        							+ "map_id INTEGER,"
	        							+ "FOREIGN KEY(map_id) REFERNCES  maps(id)";
	        
	        // gesion des erreurs avan la creation des differentes tables
	        try (PreparedStatement statement = connection.prepareStatement(mapTable)) {
	            statement.execute();
	        }
	        try (PreparedStatement statement = connection.prepareStatement(segmentsTable)) {
	            statement.execute();
	        }
	    }

	    public void insertSegments(List<Segment> segments, int mapId) {
	        String sql = "INSERT INTO segments (x1, y1, x2, y2, map_id) VALUES (?, ?, ?, ?, ?)";
	        try (PreparedStatement statement = connection.prepareStatement(sql)) {
	           // for (Segment segment : segments) {
	               // statement.setDouble(1, segment.getX1());
	                //statement.setDouble(2, segment.getY1());
	                //statement.setDouble(3, segment.getX2());
	                //statement.setDouble(4, segment.getY2());
	                //statement.setString(5, segment.getColor());
	                //statement.executeUpdate();
	           // }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    public void close() {
	        try {
	            if (connection != null) {
	                connection.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

}
