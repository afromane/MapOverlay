package classe;

import java.util.Set;

public class FindIntersection {
	
	private AVLEventEnqueue eventEnqueue;
	private AVLStatusStructure statusStructure ;
	Set<Segment> segments;
	
	public FindIntersection(Set<Segment> segments){
		this.segments = segments;
		this.eventEnqueue = new AVLEventEnqueue();
		this.statusStructure = new AVLStatusStructure();
	}
	
	
	public void find() {
		 // Etape  1: Insertion des endpoints dans  event queue  ainsi que leurs segment respectif
		for (Segment segment : this.segments) {
			this.eventEnqueue.insert(segment.getStartPoint(),segment);
			this.eventEnqueue.insert(segment.getEndPoint(),segment);
            //eventQueue.add(new Event(segment.p1, segment));
            //eventQueue.add(new Event(segment.p2, segment));
        }
		
		//Etape 3 
		

        while (!this.eventEnqueue.isEmpty()) {
        	
        	EventPoint eventPoint  = this.eventEnqueue.getNextEventPoint();
        	this.handleIntersection(eventPoint);
          /*  Event event = events.pollFirst();
            Point point = event.point;

            if (event.segment2 == null) {
                handleEndpoint(event.segment1, point);
            } else {
                handleIntersection(event.segment1, event.segment2, point, intersections);
            }*/
        }
	}
	 public void handleIntersection(EventPoint eventPoint) {
     	
     }
	

}
