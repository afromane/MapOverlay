package classe;

class Segment implements Comparable<Segment> {
    private EventPoint startPoint;
    private EventPoint endPoint;

    public Segment(EventPoint startPoint, EventPoint endPoint) {
        this.startPoint = startPoint;
        this.endPoint = endPoint;
    }

    public EventPoint getStartPoint() {
        return startPoint;
    }

    public EventPoint getEndPoint() {
        return endPoint;
    }

    @Override
    public int compareTo(Segment other) {
        int startPointComparison = this.startPoint.compareTo(other.startPoint);
        if (startPointComparison != 0) {
            return startPointComparison;
        }

        // If start points are the same, compare based on end points
        return this.endPoint.compareTo(other.endPoint);
    }
}