package classe;

 class NodeEventPoint {
    EventPoint eventPoint;
    Segment segment ;
    int height;
    NodeEventPoint left;
    NodeEventPoint right;
    public NodeEventPoint(EventPoint eventPoint,Segment segment) {
        this.eventPoint = eventPoint;
        this.segment = segment;
        this.left = null;
        this.right = null;
        this.height = 1;
    }
 
   public EventPoint getEventPoint() {
        return this.eventPoint;
    }

    public NodeEventPoint getLeft() {
        return left;
    }

    public NodeEventPoint getRight() {
        return right;
    }

    public int getHeight() {
        return height;
    }

    public void setLeft(NodeEventPoint left) {
        this.left = left;
    }

    public void setRight(NodeEventPoint right) {
        this.right = right;
    }

    public void setHeight(int height) {
        this.height = height;
    }
    public Segment getSegment() {
    	return this.segment;
    } 
    public void setSegment( Segment segment ) {
    	 this.segment = segment;
    }
}
public class AVLEventEnqueue {
	 private NodeEventPoint root;

	    public AVLEventEnqueue() {
	        this.root = null;
	    }
	    private int getHeight(NodeEventPoint node) {
	        if (node == null) {
	            return 0;
	        }
	        return node.getHeight();
	    }

	    private int getBalance(NodeEventPoint node) {
	        return node == null ? 0 :  getHeight(node.getLeft()) - getHeight(node.getRight());
	    }
	    private NodeEventPoint rotateLeft(NodeEventPoint node) {
	        NodeEventPoint newRoot = node.getRight();
	        NodeEventPoint temp = newRoot.getLeft();

	        newRoot.setLeft(node);
	        node.setRight(temp);

	       this.updateHeight(node);
	        this.updateHeight(newRoot);

	        //node.setHeight(Math.max(getHeight(node.getLeft()), getHeight(node.getRight())) + 1);
	       // newRoot.setHeight(Math.max(getHeight(newRoot.getLeft()), getHeight(newRoot.getRight())) + 1);

	        return newRoot;
	    }

	    private NodeEventPoint rotateRight(NodeEventPoint node) {
	        NodeEventPoint newRoot = node.getLeft();
	        NodeEventPoint temp = newRoot.getRight();

	        newRoot.setRight(node);
	        node.setLeft(temp);
	        this.updateHeight(node);
	        this.updateHeight(newRoot);

	        //node.setHeight(Math.max(getHeight(node.getLeft()), getHeight(node.getRight())) + 1);
	        //newRoot.setHeight(Math.max(getHeight(newRoot.getLeft()), getHeight(newRoot.getRight())) + 1);

	        return newRoot;
	    }
	    
	    private void updateHeight(NodeEventPoint node) {
	        node.height = 1 + Math.max(getHeight(node.getLeft()), getHeight(node.getRight()));
	    }
	   
	    public void insert(EventPoint eventPoint,Segment segment) {
	        root = insertNode(root, eventPoint,segment);
	    }

	    private NodeEventPoint insertNode(NodeEventPoint node, EventPoint eventPoint,Segment segment) {
	        if (node == null) {
	            return new NodeEventPoint(eventPoint,segment);
	        }

	        if (eventPoint.compareTo(node.getEventPoint()) < 0) {
	            node.setLeft(insertNode(node.getLeft(), eventPoint,segment));
	        } else if (eventPoint.compareTo(node.getEventPoint()) > 0) {
	            node.setRight(insertNode(node.getRight(), eventPoint,segment));
	        } else {
	            return node; // Duplicates not allowed
	        }

	        	// requilibrage de l'AVL
	        node.setHeight(Math.max(getHeight(node.getLeft()), getHeight(node.getRight())) + 1);
	        int balance = getBalance(node);

	        if (balance > 1 && eventPoint.compareTo(node.getLeft().getEventPoint()) < 0) {
	            return rotateRight(node);
	        }

	        if (balance < -1 && eventPoint.compareTo(node.getRight().getEventPoint()) > 0) {
	            return rotateLeft(node);
	        }

	        if (balance > 1 && eventPoint.compareTo(node.getLeft().getEventPoint()) > 0) {
	            node.setLeft(rotateLeft(node.getLeft()));
	            return rotateRight(node);
	        }

	        if (balance < -1 && eventPoint.compareTo(node.getRight().getEventPoint()) < 0) {
	            node.setRight(rotateRight(node.getRight()));
	            return rotateLeft(node);
	        }

	        return node;
	    }
	    public EventPoint getNextEventPoint() {
	        if (root == null) {
	            return null;
	        }

	        NodeEventPoint current = root;
	        while (current.left != null) {
	            current = current.left;
	        }

	        return current.eventPoint;
	    }

	    public void removeNextEvent() {
	        if (root == null) {
	            return;
	        }

	        root = removeNextEventNode(root);
	    }

	    private NodeEventPoint removeNextEventNode(NodeEventPoint node) {
	        if (node.left == null) {
	            return node.right;
	        }

	        node.left = removeNextEventNode(node.left);
	        node.height = 1 + Math.max(getHeight(node.left), getHeight(node.right));

	        int balance = getBalance(node);

	        if (balance > 1 && getBalance(node.left) >= 0) {
	            return rotateRight(node);
	        }

	        if (balance > 1 && getBalance(node.left) < 0) {
	            node.left = rotateLeft(node.left);
	            return rotateRight(node);
	        }

	        if (balance < -1 && getBalance(node.right) <= 0) {
	            return rotateLeft(node);
	        }

	        if (balance < -1 && getBalance(node.right) > 0) {
	            node.right = rotateRight(node.right);
	            return rotateLeft(node);
	        }

	        return node;
	    }

	    public boolean isEmpty() {
	        return root == null;
	    }

}
