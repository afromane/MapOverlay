package classe;
class NodeSegment {
    Segment segment;
    int height;
    NodeSegment left;
    NodeSegment right;
    public NodeSegment(Segment segment) {
        this.segment = segment;
        this.left = null;
        this.right = null;
        this.height = 1;
    }
 
   public Segment getSegment() {
        return this.segment;
    }

    public NodeSegment getLeft() {
        return left;
    }

    public NodeSegment getRight() {
        return right;
    }

    public int getHeight() {
        return height;
    }

    public void setLeft(NodeSegment left) {
        this.left = left;
    }

    public void setRight(NodeSegment right) {
        this.right = right;
    }

    public void setHeight(int height) {
        this.height = height;
    }
}
public class AVLStatusStructure {
	
	 private NodeSegment root;

	    public AVLStatusStructure() {
	        this.root = null;
	    }
	    private int getHeight(NodeSegment node) {
	        if (node == null) {
	            return 0;
	        }
	        return node.getHeight();
	    }

	    private int getBalance(NodeSegment node) {
	        return node == null ? 0 :  getHeight(node.getLeft()) - getHeight(node.getRight());
	    }
	    private NodeSegment rotateLeft(NodeSegment node) {
	    	NodeSegment newRoot = node.getRight();
	    	NodeSegment temp = newRoot.getLeft();

	        newRoot.setLeft(node);
	        node.setRight(temp);

	       this.updateHeight(node);
	        this.updateHeight(newRoot);

	        //node.setHeight(Math.max(getHeight(node.getLeft()), getHeight(node.getRight())) + 1);
	       // newRoot.setHeight(Math.max(getHeight(newRoot.getLeft()), getHeight(newRoot.getRight())) + 1);

	        return newRoot;
	    }

	    private NodeSegment rotateRight(NodeSegment node) {
	    	NodeSegment newRoot = node.getLeft();
	    	NodeSegment temp = newRoot.getRight();

	        newRoot.setRight(node);
	        node.setLeft(temp);
	        this.updateHeight(node);
	        this.updateHeight(newRoot);

	        //node.setHeight(Math.max(getHeight(node.getLeft()), getHeight(node.getRight())) + 1);
	        //newRoot.setHeight(Math.max(getHeight(newRoot.getLeft()), getHeight(newRoot.getRight())) + 1);

	        return newRoot;
	    }
	    
	    private void updateHeight(NodeSegment node) {
	        node.height = 1 + Math.max(getHeight(node.getLeft()), getHeight(node.getRight()));
	    }
	    public void insert(Segment segment) {
	       // root = insertNode(root,segment);
	    }

	    private NodeSegment insertNode(NodeSegment node, Segment segment) {
	        if (node == null) {
	            return new NodeSegment(segment);
	        }

	        if (segment.compareTo(node.getSegment()) < 0) {
	            node.setLeft(insertNode(node.getLeft(), segment));
	        } else if (segment.compareTo(node.getSegment()) > 0) {
	            node.setRight(insertNode(node.getRight(), segment));
	        } else {
	            return node; // Duplicates not allowed
	        }

	        	// requilibrage de l'AVL
	        node.setHeight(Math.max(getHeight(node.getLeft()), getHeight(node.getRight())) + 1);
	        int balance = getBalance(node);

	        if (balance > 1 && segment.compareTo(node.getLeft().getSegment()) < 0) {
	            return rotateRight(node);
	        }

	        if (balance < -1 && segment.compareTo(node.getRight().getSegment()) > 0) {
	            return rotateLeft(node);
	        }

	        if (balance > 1 && segment.compareTo(node.getLeft().getSegment()) > 0) {
	            node.setLeft(rotateLeft(node.getLeft()));
	            return rotateRight(node);
	        }

	        if (balance < -1 && segment.compareTo(node.getRight().getSegment()) < 0) {
	            node.setRight(rotateRight(node.getRight()));
	            return rotateLeft(node);
	        }

	        return node;
	    }
	   

}
